import React from 'react';

export default function App() {
  return (
    <div className="bg-black text-white font-sans">
      <section className="min-h-screen flex flex-col justify-center items-center text-center px-6 bg-gradient-to-b from-black to-gray-900">
        <h1 className="text-5xl font-bold mb-4">Få flere kunder uden at røre en finger</h1>
        <p className="text-lg text-gray-300 mb-6 max-w-2xl">
          Vi finder leads, skriver personlige cold emails og booker møder – alt for dig.
        </p>
        <div className="mb-8 w-full max-w-lg aspect-video bg-gray-800 flex items-center justify-center rounded-xl">
          <span className="text-gray-500">[Din Loom-video her]</span>
        </div>
        <a href="#cta" className="bg-yellow-400 text-black font-semibold py-3 px-6 rounded-full hover:bg-yellow-300 transition">
          Book et gratis møde
        </a>
      </section>
    </div>
  );
}
